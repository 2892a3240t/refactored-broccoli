# Slimería XL

Juego incremental de slimes (HTML5) empaquetado como app Android con Capacitor.

## Obtener el APK
1. Sube todo este contenido a un repositorio de GitHub (rama `main`).
2. Ve a la pestaña **Actions** > **Build APK**. Si no arranca solo, pulsa **Run workflow**.
3. El flujo descarga la tipografía Press Start 2P automáticamente; si por algún motivo falla, descárgala de Google Fonts y ponla en `www/fonts/PressStart2P-Regular.ttf`.
4. Cuando termine (unos 5 min), abre la ejecución y descarga **slimeria-xl-apk** en *Artifacts*. Descomprime el zip: dentro está `app-debug.apk`.
5. Pásalo al móvil/tablet e instálalo (permite «instalar apps desconocidas»).

El juego está en `www/index.html`. Cada vez que lo cambies y hagas commit se genera un APK nuevo.
